import Minter from "../components/minter";

export default function addProduct() {
    return(
        <Minter />
    )
}