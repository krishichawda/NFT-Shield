const OwnedProducts = () => {
    return(
        <>
        <h1>2Helllooooo</h1>
        </>
    )
}

export default OwnedProducts;