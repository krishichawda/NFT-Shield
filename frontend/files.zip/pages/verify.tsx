import React, { useState } from 'react'
import { Alchemy, Network } from "alchemy-sdk";
//import { sendUri } from '../components/interact';



export default function Verify() {
//const uri = sendUri();
//console.log(uri);
const [address, setAddress] = useState<string>("");
const [data, setData] = useState<any>([])
const [showNft, setShowNft] = useState<boolean>(false)

const config = {
  apiKey: "3OGlmNKSI58c0xfNbKDSTGZYRUwv86Jm",
  network: Network.MATIC_MUMBAI,
};
const alchemy = new Alchemy(config);

const handleClick = async () => {
  console.log(address)
  // Get all NFTs
  const nfts = await alchemy.nft.getNftsForOwner(address);
  console.log(nfts)
  setShowNft(true);

  //  let re = /Buildspace/gi;

  // Print NFTs
//   for (let i=0; i < 3; i++ ) {
//  // console.log(nfts.ownedNfts[i].rawMetadata);
//   if(nfts.ownedNfts[i].rawMetadata?.name?.search(re) == -1) {
//     console.log("no available nft")
//   }
//   else {
//     data.push(nfts.ownedNfts[i].rawMetadata);
//   }
//   }
//   console.log(data);
};

const handleChange = (e: React.FormEvent<HTMLInputElement>) => {
  setAddress(e.currentTarget.value);
  //console.log(address)

}

  return (
    <>
    <div className='my-12 border-2 pt-8 w-2/6 rounded-3xl mx-auto' >
    <div className='flex flex-row justify-center mx-auto font-bold text-xl'>Verify Your NFT</div>
    <input className='flex flex-row justify-center w-4/6 px-2 mt-10 mx-auto border-2 rounded-lg' placeholder='Wallet Address' type="text" onChange={handleChange}/>
    <div className="flex w-full justify-center py-10">
          <input className='w-28 h-10 text-white bg-black rounded-full items-center text-center py-2' type="submit" onClick={handleClick}/>
        </div>
        </div>
        <div className='grid grid-cols-3 gap-4'>
        {showNft &&
          data.map((item: { name: string, image: string, description: string }, i: React.Key) => (
              <div className='border-2 rounded-xl mx-5 mt-10'>
              <img src={item.image} alt='nft image' />
              <p>{item.name}</p>
              {item.description}
              </div>
            ))
          }
          </div>
    </>

  )
}



// 167legR0GoM_CxCz8GFnjf7t0H7OmEe-