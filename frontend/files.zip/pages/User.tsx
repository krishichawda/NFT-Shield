import { JSXElementConstructor, Key, ReactElement, ReactFragment, ReactPortal, useEffect, useRef, useState } from "react"
import { Alchemy, Network } from "alchemy-sdk";
import { ConstructionOutlined, Description } from "@mui/icons-material";
import { Contract, ethers, Signer } from "ethers";
import { userAgent } from "next/server";
import { getCurrentWalletConnected } from "../components/interact";
import { providers } from "ethers";
import Web3Modal from "@web3modal/react";
import { useContract } from "../hooks/useContract";
import { CONTRACT_ABI, CONTRACT_ADDRESS } from "../constants";
import { BigNumber } from "ethers";
import { db } from "../firebase/firebase";
import { getDocs, collection } from "@firebase/firestore";
import { async } from "@firebase/util";
const axios = require('axios');
const alchemyKey = "https://polygon-mumbai.g.alchemy.com/v2/3OGlmNKSI58c0xfNbKDSTGZYRUwv86Jm";
const { createAlchemyWeb3 } = require("@alch/alchemy-web3");
//const [uri, setUri] = useState([])
const web3 = createAlchemyWeb3(alchemyKey);


export default function test() {

const [data, setData] = useState<any>([]);
const [showbtn, setShowbtn] = useState<boolean>(true);
const [tokenId, setTokenId] = useState<any>([]);
const tokensCollectionRef = collection(db, "tokens");
const [final, setFinal] = useState<any>([]);
const [new_data, setNewData] = useState<any>([]);


const [name, setName] = useState<any>([]);
const [image, setImage] = useState<any>([]);
const [description, setDescription] = useState<any>([]);
const [price, setPrice] = useState<any>([]);
// const web3ModalRef = useRef();
//  const[name, setName] = useState<any>([]);
const abi = CONTRACT_ABI;

const address = CONTRACT_ADDRESS;

//const omitMetadata = false;


// const config = {
//   apiKey: "rcBG6P4ZncpudOqWHHfVcE4eJHQ_7Gaz",
//   network: Network.MATIC_MUMBAI,
// };
// const alchemy = new Alchemy(config);

const handleClick = async(Id: number) => {

  const querySnapshot = await getDocs(tokensCollectionRef);
  querySnapshot.forEach((doc) => {
    // doc.data() is never undefined for query doc snapshots
    new_data.push(doc.data()["uri"]);
   // console.log(doc.id, " => ", doc.data());
  });

    if (window.ethereum) {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const contract = new ethers.Contract(address, abi, signer);
      console.log("Going to pop wallet now to pay gas")
      window.contract = await new web3.eth.Contract(CONTRACT_ABI, CONTRACT_ADDRESS);//loadContract();

      //set up your Ethereum transaction
      const transactionParameters = {
          to: CONTRACT_ADDRESS, // Required except during contract publications.
          from: window.ethereum.selectedAddress, // must match user's active address.
          'data': window.contract.methods.safeMint(window.ethereum.selectedAddress, new_data[Id]).encodeABI() //make call to NFT smart contract 
      };

      //sign transaction via Metamask
      try {
          const txHash = await window.ethereum
              .request({
                  method: 'eth_sendTransaction',
                  params: [transactionParameters],
              });
          return {
              success: true,
              status: "✅ Check out your transaction on Etherscan: https://goerli.etherscan.io/tx/" + txHash
          }
      } catch (error: any) {
          return {
              success: false,
              status: "😥 Something went wrong: " + error.message
          }
      }
    }
  }


const main = async () => {
  // Get all NFTs
//   const response = await alchemy.nft.getNftsForContract(address, {
//     omitMetadata: omitMetadata,
//   });
//   // console.log(response.nfts[1].rawMetadata)
//   console.log(response)
//  // data.push(response.nfts[0].rawMetadata)
//  // console.log(data[0].name)
//  for(let i = 0; i < response.nfts.length; i++) {
//   setData((data: any) => [...data, response.nfts[i].rawMetadata]);
//   setTokenId((tokenId: any) => [...tokenId, response.nfts[i].tokenId]);
 // console.log(data)
 const querySnapshot = await getDocs(tokensCollectionRef);
 querySnapshot.forEach((doc) => {
   // doc.data() is never undefined for query doc snapshots
   final.push(doc.data()["uri"]);
  // console.log(doc.id, " => ", doc.data());
 });

//console.log(final);

async function getData() {
	try {
    for(let i = 0; i < final.length; i++){
		const response = await axios.get(final[i]);
		//console.log(response.data);
    const metadata = {
      Id: i,
      name: response.data["name"],
      image: response.data["image"],
      description : response.data["description"],
      price : response.data["price"]
    }
    name.push(response.data["name"])
    image.push(response.data["image"])
    description.push(response.data["description"])
    price.push(response.data["price"])
  //  const jsondata = JSON.stringify(metadata);
  console.log(metadata)
  //  data[i] = metadata;
  data.push(metadata)

    }
}
	catch (error) {
		console.log(error);
	}
}

 const res = await getData();
//  console.log(name)
//  console.log(image)
//  console.log(price)
//  console.log(description)
// console.log(data[0]["name"])
 setShowbtn(false);


}
  // setName((name: any) => [...name, response.nfts[0].rawMetadata?.name])
 // console.log(JSON.stringify(response, null, 2));



return (
  <>
  <div className="flex w-full justify-center py-10">
  {showbtn && <button className="border-2 p-3 rounded-xl bg-black text-white" onClick={main}>Show Products</button>}
  </div>
  {!showbtn &&
          data.map(({Id, name, image, description, price} : any) =>
          <div className='grid grid-cols-3 gap-4'>
          <div className='border-2 rounded-xl mx-5 mt-10'>
          <p key={name}> {name} {description} {price} </p>
          <img src={image} />
          <button className='w-28 h-10 bg-black text-white ml-16 rounded-full items-center text-center py-2' onClick={() => handleClick(Id)}>Buy</button>
          </div>
          </div>
          )
      }

  </>
  )
 }
