import React, { useEffect, useState } from 'react';
import Cart from './cart'
import { useRouter } from 'next/router'
import { Alchemy, Network } from "alchemy-sdk";
import { addToCart } from '../redux/cart.slice';
import { useDispatch } from 'react-redux';
import { ProductCard} from '../components/ProductCard';
import { PropertyDeclaration } from 'typescript';

export default function listedProducts() {

  const dispatch = useDispatch();

  const [data, setData] = useState<any>([])

  const address = "0xD3e6F67cf34358D6035B40779CA63C53Fb752B49";
  const config = {
    apiKey: "rcBG6P4ZncpudOqWHHfVcE4eJHQ_7Gaz",
    network: Network.MATIC_MUMBAI,
  };

  useEffect(() => {

    const alchemy = new Alchemy(config);
    (async () => {
      const nfts = await alchemy.nft.getNftsForOwner(address);
      console.log(nfts.ownedNfts);
    })

  });


//  for (let i = 0; i < 3; i++){
   // data.push(nfts.ownedNfts[i].rawMetadata)
  //}
  //console.log(data)

  const product = {
    "name": "NBA2K21 Next Generation",
	  "description": "ps5",
	  "image": "https://imgur.com/Mxjvkws.png"
  }

type Item = {
  name: string
  description : string
  image: string
  }


  return (
    <>
    <div className="max-w-sm rounded overflow-hidden shadow-lg">
  <img className="w-full" src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pexels.com%2Fsearch%2Fbeautiful%2F&psig=AOvVaw3K-JCAIrweZn1h3ZL8xwk-&ust=1672382310232000&source=images&cd=vfe&ved=0CA8QjRxqFwoTCIC0z92bnvwCFQAAAAAdAAAAABAE" alt="Sunset in the mountains"/>
  <div className="px-6 py-4">
    <div className="font-bold text-xl mb-2">a name placeholder</div>
    <p className="text-gray-700 text-base">
      a simple image
      </p>
  </div>
  <div className="px-6 pt-4 pb-2">
    <button className="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700 mr-2 mb-2"  onClick={() => dispatch(addToCart(product))}>Add to Cart</button>
  </div>
</div>


    </>
  )
}


