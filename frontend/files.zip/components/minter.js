import { initializeApp } from "firebase/app";
import { useEffect, useState } from "react";
import {
  connectWallet,
  getCurrentWalletConnected,
} from "./interact.js";
import { pinJSONToIPFS } from "./pinata.js";
import { db } from "../firebase/firebase.ts";
import { collection, addDoc } from "firebase/firestore"
import { CONTRACT_ABI, CONTRACT_ADDRESS } from "../constants.ts";


const Minter = (props) => {
  const [walletAddress, setWallet] = useState("");
  const [status, setStatus] = useState("")
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState(0);
  const [image, setImage] = useState(null);
  const axios = require('axios');
  const contractABI = CONTRACT_ABI;
  const contractAddress = CONTRACT_ADDRESS;
 // const mongo_url = "mongodb+srv://krishicoc:<krishi1234>@cluster0.3xrp8qm.mongodb.net/?retryWrites=true&w=majority";
  // const dbName = 'nft_warranty';
  // mongo.connect(mongo_url, {useNewUrlParser: true }, (err, client) => {
  //   if (err) {
  //    console.error(err)
  //    return
  //  }
  //   console.log('Connected successfully to server')
  //   const db = client.db(dbName)
  //  })
  //  const collection = db.collection('tokens')


  useEffect(() => {
    const { address, status } = getCurrentWalletConnected();

    setWallet(address);
    setStatus(status);

    addWalletListener();
  }, []);

  function addWalletListener() {
    if (window.ethereum) {
      window.ethereum.on("accountsChanged", (accounts) => {
        if (accounts.length > 0) {
          setWallet(accounts[0]);
          setStatus("Write a message in the text-field above.");
        } else {
          setWallet("");
          setStatus("Connect to Metamask using the top right button.");
        }
      });
    } else {
      setStatus(
        <p>
          {" "}
          🦊{" "}
          <a target="_blank" href={`https://metamask.io/download.html`}>
            You must install Metamask, a virtual Ethereum wallet, in your
            browser.
          </a>
        </p>
      );
    }
  }

  const connectWalletPressed = async () => {
    const walletResponse = await connectWallet();
    setStatus(walletResponse.status);
    setWallet(walletResponse.address);
  };


  const mintNFT = async(url, name, description, price) => {
    // const [data, setData] = useState([])
    const data = []
     //error handling
     if (name.trim() == "" || description.trim() == "") {
       return {
        success: false,
        status: "❗Please make sure all fields are completed before minting.",
       }
      }

      //make metadata
     const metadata = new Object();
     metadata.name = name;
     metadata.image = url;
     metadata.description = description;
     metadata.price = price;
    // setResult(metadata);
     //make pinata call
     const pinataResponse = await pinJSONToIPFS(metadata);
     if (!pinataResponse.success) {
         return {
             success: false,
             status: "😢 Something went wrong while uploading your tokenURI.",
         }
     }
     const tokenURI = pinataResponse.pinataUrl;
     console.log(tokenURI);

     const tokenCollectionRef = collection(db, "tokens");
     addDoc(tokenCollectionRef, {uri: tokenURI});
    //  data.push(tokenURI)
    //  console.log(data);
    return {
      success: true,
      status: "✅ Check out your transaction on Etherscan: https://goerli.etherscan.io/tx/" 
  }

  }

    //  collection.insertOne(tokenURI, ((error, item) => {
    //   if(error) {
    //    console.error(error)
    //    return
    //   }
    //    console.log(item)
    //  }));



  const onMintPressed = async () => {
    if (image) {
      try {
          const formData = new FormData();
          formData.append("file", image);

          const resFile = await axios({
              method: "post",
              url: "https://api.pinata.cloud/pinning/pinFileToIPFS",
              data: formData,
              headers: {
                  'pinata_api_key': `befd68f8ceb8cbedc662`,
                  'pinata_secret_api_key': `d8a392b686ca2f102c808641959311ab15b1108230a2a363b26c68e418555345`,
                  "Content-Type": "multipart/form-data"
              },
          });

      //  const ImgHash = `ipfs://${resFile.data.IpfsHash}`;
      //  console.log(ImgHash);
      const url = `https://gateway.pinata.cloud/ipfs/${resFile.data.IpfsHash}`
      console.log(url);

    const {success, status } = await mintNFT(url, name, description, price);
    setStatus(status);
    if (success) {
      setName("");
      setDescription("");
      setPrice(0);
    } }
    catch (error) {
      console.log("Error sending File to IPFS: ")
      console.log(error)
  }
  }
};

  return (
    <div className="Minter">
      <button id="walletButton" onClick={connectWalletPressed}>
        {String(walletAddress).length > 0 ? (
          "Connected: " +
          String(walletAddress).substring(0, 6) +
          "..." +
          String(walletAddress).substring(38)
        ) : (
          <span>Connect Wallet</span>
        )}
      </button>

      <br></br>
      <h1 id="title">Create Your Product</h1>
      <p>
        Simply add your asset's link, name, and description, then press "Mint."
      </p>
      <form>
        {/* <h2>🖼 Link to asset: </h2>
        <input
          type="text"
          placeholder="e.g. https://gateway.pinata.cloud/ipfs/<hash>"
          onChange={(event) => setURL(event.target.value)}
        /> */}
        <h2>🤔 Name: </h2>
        <input
          type="text"
          placeholder="e.g. My first NFT!"
          onChange={(event) => setName(event.target.value)}
        />
        <h2>✍️ Description: </h2>
        <input
          type="text"
          placeholder="e.g. Even cooler than cryptokitties ;)"
          onChange={(event) => setDescription(event.target.value)}
        />
         <h2> Price : </h2>
         <input
          type="number"
          placeholder="Enter Price"
          onChange={(event) => setPrice(event.target.value)}
        />
        <h2 class="text-lg font-bold mb-2" required>🖼 Image: </h2>
          <input type="file" accept="image/*" onChange={(event) => setImage(event.target.files[0])} />
      </form>
      <button id="mintButton" onClick={onMintPressed}>
        Mint NFT
      </button>
      <p id="status" style={{ color: "red" }}>
        {status}
      </p>
    </div>
  );
};

export default Minter;